#include "Ifx_Types.h"
#include "IfxGpt12.h"
#include "IfxPort.h"
#include "Bsp.h"
#include "IfxCpu.h"
#include "IfxScuWdt.h"

/*********************************************************************************************************************/
/*------------------------------------------------------Macros-------------------------------------------------------*/
/*********************************************************************************************************************/
#define ISR_PRIORITY_GPT12_T2_INT   9              /* Define the GPT12 Timer 2 interrupt priority                  */
#define ISR_PRIORITY_GPT12_T3_INT   10              /* Define the GPT12 Timer 2 interrupt priority                  */
#define ISR_PRIORITY_GPT12_T4_INT   11              /* Define the GPT12 Timer 2 interrupt priority                  */
#define MAX_VAL_16_BIT              0xFFFF          /* Used for calculation of timer value with overflows           */

#define PWM_PIN                     &MODULE_P00,8   /* Pin which is used to generate a simple PWM signal            */
#define T3_OUT_PIN                  &MODULE_P02,0
#define Test_PIN                    &MODULE_P10,4
/*----------------sonar pin----------------------*/
#define TRIG_PIN                    &MODULE_P02,3
#define ECHO_PIN                    &MODULE_P00,7

//PWM DUTY ����
#define PWM_DUTY                  0.12             /* Duty cycle of generated PWM signal, value between 0 and 1    */
#define FACTOR_SEC_TO_USEC        1000000         /* Factor to convert seconds to microseconds                    */
#define WAIT_TIME                 1
/*********************************************************************************************************************/
/*-------------------------------------------------Global variables--------------------------------------------------*/
/*********************************************************************************************************************/
float32 g_generatedPwmFreq_Hz_sonar   = 50.0; /* Global variable for frequency of generated PWM signal                    */
float32 g_measuredPwmFreq_Hz_sonar    = 0.0;  /* Global variable for frequency calculation of PWM signal                  */
uint32  g_cntOverflow           = 0;    /* Global counter variable for the timer overflow between two edges         */
uint32  g_cntOverflow_rising    = 0;    /* Global counter variable for the timer overflow between two edges         */
uint32  g_cntOverflow_falling   = 0;    /* Global counter variable for the timer overflow between two edges         */
uint32  g_previousCntVal_sonar        = 0;    /* Global variable which stores the timer value of the previous interrupt   */

uint32 currentCntVal_rising = 0;
uint32 currentCntVal_falling = 0;
/*********************************************************************************************************************/
/*---------------------------------------------Function Implementations----------------------------------------------*/
/*********************************************************************************************************************/
/* Macro to define the Interrupt Service Routine */
extern uint32 finalCntVal_main;
extern float32 T3_frequency_main;

//����
extern uint32  g_cntOverflow_main;
extern uint32  g_previousCntVal_main;
extern uint32  currentCntVal_main;

extern uint32 elaps_cnt_val;

int type_edge = 1;
int total_time =0 ;
IFX_INTERRUPT(GPT12_T2_Int0_Handler, 0, ISR_PRIORITY_GPT12_T2_INT);
IFX_INTERRUPT(GPT12_T4_Int0_Handler, 0, ISR_PRIORITY_GPT12_T4_INT);

int trig_flag = 0;
extern uint32 obs_distance;
extern float32 obs_float_distance;
/* Interrupt Service Routine of timer T2, gets triggered by rising edge on input pin of timer T2 */
void GPT12_T2_Int0_Handler(void)
{
    uint32 currentCntVal = IfxGpt12_T2_getTimerValue(&MODULE_GPT120); /* Get timer value of timer T2 */
    uint32 finalCntVal = 0; /* Variable to calculate final timer counter value */

        IfxPort_setPinState(Test_PIN, IfxPort_State_high);
        waitTime(IfxStm_getTicksFromMicroseconds(BSP_DEFAULT_TIMER, WAIT_TIME));
        IfxPort_setPinState(Test_PIN, IfxPort_State_low);
    //����� �����÷ο찡 �߻��߳�
    currentCntVal_main = currentCntVal;
    g_previousCntVal_main = g_previousCntVal_sonar;
    if(g_cntOverflow == 0)
    {
        /* If no overflow detected */
        finalCntVal = currentCntVal - g_previousCntVal_sonar; /* Total counter value calculation */
    }
    else
    {
        /* One or more overflows detected */
        /* Add to the current counter value, the amount of counter ticks which passed before the first overflow,
         * plus 65525 (0xFFFF) for each additional overflow since the previous rising edge.
         */
        // ���� �ð����� 655~ ������ ���̸� ���ؾ��ϱ� ������ ����
        finalCntVal = (uint32)(currentCntVal + (MAX_VAL_16_BIT - g_previousCntVal_sonar) + ((g_cntOverflow - 1) * MAX_VAL_16_BIT));// MAX_VAL_16_BIT = 65535
    }

   // finalCntVal_main = finalCntVal;
    T3_frequency_main = IfxGpt12_T3_getFrequency(&MODULE_GPT120);
    /* Calculation of the PWM frequency by dividing the frequency of timer T3 through the final total counter value */
    g_measuredPwmFreq_Hz_sonar = IfxGpt12_T3_getFrequency(&MODULE_GPT120) / finalCntVal;

    finalCntVal_main = finalCntVal;
    g_previousCntVal_sonar = currentCntVal;    /* Set g_previousCntVal to currentCntVal for the next calculation */
    g_cntOverflow_main = g_cntOverflow;

    if(type_edge == 1)
    {
        IfxGpt12_T2_setCaptureInputMode(&MODULE_GPT120, IfxGpt12_CaptureInputMode_fallingEdgeTxIN);
        type_edge = 0;
        g_cntOverflow = 0;                   /* Reset overflow flag */
        g_cntOverflow_rising = g_cntOverflow;
        currentCntVal_rising = currentCntVal;
    }
    else
    {
        IfxGpt12_T2_setCaptureInputMode(&MODULE_GPT120, IfxGpt12_CaptureInputMode_risingEdgeTxIN);
        type_edge = 1;
        g_cntOverflow_falling = g_cntOverflow;
        currentCntVal_falling = currentCntVal;

        elaps_cnt_val = (uint32)(currentCntVal_falling + (MAX_VAL_16_BIT - currentCntVal_rising) + (g_cntOverflow_falling - g_cntOverflow_rising -1) * MAX_VAL_16_BIT);
        obs_distance =  340*(elaps_cnt_val*40)/1000000/2; //������ �ӵ�-340m/s ����(elaps_cnt_val)�� �ʷ� ��ȯ ������ 1000000000 �׸��� mm��� *1000 �׷��� 1000000����
        obs_float_distance =  (float32)(340*(elaps_cnt_val*40))/1000000/2;
    }
   // g_cntOverflow = 0;                   /* Reset overflow flag */
}

/* Macro to define the Interrupt Service Routine. */
IFX_INTERRUPT(GPT12_T3_Int0_Handler, 0, ISR_PRIORITY_GPT12_T3_INT);

/* Interrupt Service Routine of timer T3, gets triggered after T3 timer overflow */
void GPT12_T3_Int0_Handler(void)
{
    g_cntOverflow++; /* Increase overflow counter */
    IfxPort_setPinState(T3_OUT_PIN, IfxPort_State_high);
    waitTime(IfxStm_getTicksFromMicroseconds(BSP_DEFAULT_TIMER, WAIT_TIME));
    IfxPort_setPinState(T3_OUT_PIN, IfxPort_State_low);
}

void GPT12_T4_Int0_Handler(void)
{
      //  IfxPort_setPinState(T4_OUT_PIN, IfxPort_State_high);
       // waitTime(IfxStm_getTicksFromMilliseconds(BSP_DEFAULT_TIMER, WAIT_TIME));
       // IfxPort_setPinState(T4_OUT_PIN, IfxPort_State_low);
}

/* This function initializes timer T2 and T3 of the block GPT1 of module GPT12 to capture PWM signals. */
void init_GPT12_module(void)
{
    /* Enable GPT12 module */
    IfxGpt12_enableModule(&MODULE_GPT120);
    /* Select 4 as prescaler for the GPT1 module -> fastest clock frequency for best accuracy */
    IfxGpt12_setGpt1BlockPrescaler(&MODULE_GPT120, IfxGpt12_Gpt1BlockPrescaler_4);
    /* Set core timer T3 in timer mode */
    IfxGpt12_T3_setMode(&MODULE_GPT120, IfxGpt12_Mode_timer);
    /* Set auxiliary timer T2 in capture mode */
    IfxGpt12_T2_setMode(&MODULE_GPT120, IfxGpt12_Mode_capture);
    /* Select input pin A of timer T2 which is P00.7 (the James Bond pin) ->pwm signal capture */
    IfxGpt12_T2_setInput(&MODULE_GPT120, IfxGpt12_Input_A); //
    /* Select rising edge as capture event */
    IfxGpt12_T2_setCaptureInputMode(&MODULE_GPT120, IfxGpt12_CaptureInputMode_risingEdgeTxIN);


    /// T4 -> �ɿ��ᶧ���� �Ⱦ�

    //IfxGpt12_T4_setMode(&MODULE_GPT120, IfxGpt12_Mode_capture);
    //* Select input pin A of timer T2 which is P00.7 (the James Bond pin) ->pwm signal capture */
    //IfxGpt12_T4_setInput(&MODULE_GPT120, IfxGpt12_Input_A); //
    /* Select rising edge as capture event */
   // IfxGpt12_T4_setCaptureInputMode(&MODULE_GPT120, IfxGpt12_CaptureInputMode_fallingEdgeTxIN);


    /* Service request configuration */
    /* Get source pointer of timer T2, initialize and enable */
    volatile Ifx_SRC_SRCR *src = IfxGpt12_T2_getSrc(&MODULE_GPT120);
    IfxSrc_init(src, IfxSrc_Tos_cpu0, ISR_PRIORITY_GPT12_T2_INT);
    IfxSrc_enable(src);
    /* Get source pointer of timer T3, initialize and enable */
    src = IfxGpt12_T3_getSrc(&MODULE_GPT120);
    IfxSrc_init(src, IfxSrc_Tos_cpu0, ISR_PRIORITY_GPT12_T3_INT);
    IfxSrc_enable(src);

    //src = IfxGpt12_T4_getSrc(&MODULE_GPT120);
      //IfxSrc_init(src, IfxSrc_Tos_cpu0, ISR_PRIORITY_GPT12_T4_INT);
      //IfxSrc_enable(src);

    /* Initialize ECHO_PIN port pin */
    //IfxPort_setPinMode(ECHO_PIN,  IfxPort_Mode_inputNoPullDevice );
    //IfxPort_setPinState(ECHO_PIN, IfxPort_State_low);

    /* Initialize TRIG_PIN port pin */
       IfxPort_setPinMode(TRIG_PIN, IfxPort_Mode_outputPushPullGeneral); /* Initialize PWM_PIN port pin */
       IfxPort_setPinState(TRIG_PIN, IfxPort_State_low);

       IfxPort_setPinMode(T3_OUT_PIN, IfxPort_Mode_outputPushPullGeneral); /* Initialize PWM_PIN port pin */
       IfxPort_setPinState(T3_OUT_PIN, IfxPort_State_low);

       IfxPort_setPinMode(Test_PIN, IfxPort_Mode_outputPushPullGeneral); /* Initialize PWM_PIN port pin */
            IfxPort_setPinState(Test_PIN, IfxPort_State_low);
       //IfxPort_setPinMode(T4_OUT_PIN, IfxPort_Mode_outputPushPullGeneral);
      // IfxPort_setPinState(T4_OUT_PIN, IfxPort_State_low);
    /* Start timer T3*/
    //IfxGpt12_T2_run(&MODULE_GPT120, IfxGpt12_TimerRun_start);
    IfxGpt12_T3_run(&MODULE_GPT120, IfxGpt12_TimerRun_start);
    //IfxGpt12_T4_run(&MODULE_GPT120, IfxGpt12_TimerRun_start);

}

/* Generation of simple PWM signal by toggling a pin (frequency can be changed during runtime) */

void Trig_Signal(void)
{
    sint32 targetWaitTime_1ms = IfxStm_getTicksFromMilliseconds(BSP_DEFAULT_TIMER, 1);
    sint32 targetWaitTime_100ms = IfxStm_getTicksFromMilliseconds(BSP_DEFAULT_TIMER, 100);
    /* Set the pin high to trigger an interrupt */

        IfxPort_setPinState(TRIG_PIN, IfxPort_State_high);
        /* Wait for an amount of CPU ticks that represent the calculated microseconds considering the duty cycle */
        wait(targetWaitTime_1ms);
        /* Set pin state to low */
        IfxPort_setPinState(TRIG_PIN, IfxPort_State_low);
        /* Wait for an amount of CPU ticks that represent the calculated microseconds considering the duty cycle */
        wait(targetWaitTime_100ms);
}
